﻿namespace BorderControl
{
    public interface IPerson
    {
        public string Name { get; }

        public string Age { get; }
    }
}
