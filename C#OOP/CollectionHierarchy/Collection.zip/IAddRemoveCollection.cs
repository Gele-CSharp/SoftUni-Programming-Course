﻿namespace CollectionHierarchy
{
    public interface IAddRemoveCollection
    {
        public abstract string Remove();
    }
}
