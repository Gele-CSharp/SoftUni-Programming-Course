﻿using System;
using System.Collections.Generic;

namespace CustomStack
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            StackOfStrings stackOfStrings = new StackOfStrings();

            List<string> list = new List<string>() { "Pesho", "Gosho", "Tosho" };

            stackOfStrings.AddRange(list);

            foreach (var item in stackOfStrings)
            {
                Console.WriteLine(item);
            }
            
        }
    }
}
