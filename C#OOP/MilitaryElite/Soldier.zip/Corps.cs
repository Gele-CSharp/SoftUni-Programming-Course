﻿namespace MilitaryElite
{
    public enum Corps
    {
        Airforces,
        Marines
    }
}
