﻿namespace MilitaryElite
{
    public interface IPrivate : ISoldier
    {
        public decimal Salary { get; set; }
    }
}
