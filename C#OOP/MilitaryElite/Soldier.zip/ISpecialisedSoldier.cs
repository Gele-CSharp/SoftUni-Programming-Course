﻿namespace MilitaryElite
{
    interface ISpecialisedSoldier : IPrivate
    {
        public Corps Corps { get; set; }
    }
}
