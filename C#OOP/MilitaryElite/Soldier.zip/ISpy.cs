﻿namespace MilitaryElite
{
    interface ISpy : ISoldier
    {
        public int CodeNumber { get; set; }
    }
}
