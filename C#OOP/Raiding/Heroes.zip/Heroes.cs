﻿namespace Raiding
{
    public enum Heroes
    {
        Druid,
        Paladin,
        Rogue,
        Warrior
    }
}
