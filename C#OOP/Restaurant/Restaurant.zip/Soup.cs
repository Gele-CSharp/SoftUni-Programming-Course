﻿namespace Restaurant
{
    public class Soup : Food
    {
        public Soup(string name, decimal price, double grams) 
            : base(name, price, grams)
        {
        }
    }
}
