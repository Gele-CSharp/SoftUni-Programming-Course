﻿namespace Telephony
{
    interface ISmartphone : IStationaryPhone
    {
        void Browse(string url);
    }
}
