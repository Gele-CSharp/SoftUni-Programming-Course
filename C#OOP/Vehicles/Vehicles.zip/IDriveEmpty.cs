﻿namespace Vehicles
{
    public interface IDriveEmpty
    {
        public void DriveEmpty(double distance);
    }
}
