﻿namespace WildFarm.Foods
{
    public  interface IFood
    {
        public int Quantity { get; }
    }
}
